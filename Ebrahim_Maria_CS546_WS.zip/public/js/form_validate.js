// In this file, you must perform all client-side validation for every single form input (and the role dropdown) on your pages. The constraints for those fields are the same as they are for the data functions and routes. Using client-side JS, you will intercept the form's submit event when the form is submitted and If there is an error in the user's input or they are missing fields, you will not allow the form to submit to the server and will display an error on the page to the user informing them of what was incorrect or missing.  You must do this for ALL fields for the register form as well as the login form. If the form being submitted has all valid data, then you will allow it to submit to the server for processing. Don't forget to check that password and confirm password match on the registration form!

document.addEventListener('DOMContentLoaded', () => {
    const signinForm = document.getElementById('signin-form');
    const signupForm = document.getElementById('signup-form');

    let backgroundColor = document.getElementById('backgroundColor').value;
            let fontColor = document.getElementById('fontColor').value;
            document.documentElement.style.setProperty('--background-color', backgroundColor);
            document.documentElement.style.setProperty('--font-color', fontColor);

    if(signupForm){
        signupForm.addEventListener('submit', (event) => {
            event.preventDefault();
            let err = document.getElementById('error');
            err.textContent = "";

            try{

            let missingItems = "";

            let firstName = document.getElementById("firstName").value;
            let lastName = document.getElementById("lastName").value;
            let userId = document.getElementById("userId").value;
            let password = document.getElementById("password").value;
            let confirmPassword = document.getElementById("confirmPassword").value;
            let favoriteQuote = document.getElementById("favoriteQuote").value;
            let backgroundColor = document.getElementById("backgroundColor").value.toString();
            let fontColor = document.getElementById("fontColor").value.toString();
            let role = document.getElementById("role").value;
            
            if(!firstName){
                missingItems += "First Name\n";
            }

            if(!lastName){
                missingItems += "Last Name\n";
            }

            if(!userId){
                missingItems += "userId\n";
            }

            if(!password){
                missingItems += "Password\n";
            }

            if(!confirmPassword){
                missingItems += "Confirm Password\n";
            }

            if(!favoriteQuote){
                missingItems += "Favorite Quote\n";
            }

            if(!backgroundColor){
                missingItems += "Background Color\n";
            }

            if(!fontColor){
                missingItems += "Font Color\n";
            }

            if(!role){
                missingItems += "Role\n";
            }

            if(missingItems.length > 1){
                let err = "The following feilds are missing:\n" + missingItems;
                throw err 
            }
            

            if(typeof firstName !== 'string') throw "improper paramater type for first name helloo";
            if(typeof lastName !== 'string') throw "improper paramater typefor last name";
          
            if((/\d/.test(firstName))) throw "number in first name";
            if((/\d/.test(lastName))) throw "number in last name";
          
            firstName = firstName.trim();
            lastName = lastName.trim();
          
            if(firstName.length < 2) throw "short string for first name";
            if(lastName.length < 2) throw "short string for last name";
          
            if(firstName.length > 25) throw "long string";
            if(lastName.length > 25) throw "long string";
          
            if(typeof userId !== 'string') throw "improper paramater type";
            if((/\d/.test(userId))) throw "number in userId";
            userId = userId.trim().toLowerCase();
            if(userId.length < 5) throw "short string";
            if(userId.length > 10) throw "long string";
          
            if(typeof password !== 'string') throw "improper paramater type";
            password = password.trim();
            if(password.includes(" ")) throw "space in password";
            if(password.length < 8) throw "short password";
            if(!(/\d/.test(password))) throw "include number in password";
            if(!(/[A-Z]/.test(password))) throw "include uppercase in password";
            if(!(/[^a-zA-Z0-9]/.test(password))) throw "include special character in password";

            if(confirmPassword !== password) throw "passwords do not match";
          
            if(typeof favoriteQuote !== 'string') throw "improper parameter";
            favoriteQuote = favoriteQuote.trim();
            if(favoriteQuote.length < 20) throw "short string";
            if(favoriteQuote.length > 255) throw "long string";

            if(!(/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$/.test(backgroundColor))) throw "invalid hex";
            if(!(/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$/.test(fontColor))) throw "invalid hex";
            if(backgroundColor === fontColor) throw "same color";
    
            if(typeof role !== 'string') throw "invalid parameter";
            role = role.trim().toLowerCase();
            if(role !== "admin" && role !== "user") throw "role must be admin or user";

            else{
                signupForm.submit();
            }}catch(e){
                err.textContent = e;
            }
        });
    }


    if(signinForm){
        signinForm.addEventListener('submit', (event) => {
            event.preventDefault();
            let err = document.getElementById('error');
            err.textContent = "";
            // let backgroundColor = document.getElementById('backgroundColor').value;
            // let fontColor = document.getElementById('fontColor').value;
            // document.documentElement.style.setProperty('--background-color', backgroundColor);
            // document.documentElement.style.setProperty('--font-color', fontColor);
            try{
            let userId = document.getElementById("user_id").value;
            let password = document.getElementById("password").value;
            
            if(!userId || !password) throw "missing params";

            if(typeof userId !== 'string') throw "improper paramater type";
            if((/\d/.test(userId))) throw "number in userId";
            userId = userId.trim().toLowerCase();
            if(userId.length < 5) throw "short string";
            if(userId.length > 10) throw "long string";

            if(typeof password !== 'string') throw "improper paramater type";
            password = password.trim();
            if(password.includes(" ")) throw "space in password";
            if(password.length < 8) throw "short password";
            if(!(/\d/.test(password))) throw "include number in password";
            if(!(/[A-Z]/.test(password))) throw "include uppercase in password";
            if(!(/[^a-zA-Z0-9]/.test(password))) throw "include special character in password";

            else{
                signinForm.submit();
            }}catch(e){
                err.textContent = e;
            }
        });
    }

});
