//import mongo collections, bcrypt and implement the following data functions

import bcrypt from 'bcrypt';
import {users} from '../config/mongoCollections.js';

const saltRounds = 16;

export const signUpUser = async (
  firstName,
  lastName,
  userId,
  password,
  favoriteQuote,
  themePreference,
  role
) => {
  if(!firstName || !lastName || !userId || !password || !favoriteQuote || !themePreference || !role) throw "missing an input param";
  if(typeof firstName !== 'string') throw "improper paramater type";
  if(typeof lastName !== 'string') throw "improper paramater type";

  if((/\d/.test(firstName))) throw "number in first name";
  if((/\d/.test(lastName))) throw "number in last name";

  firstName = firstName.trim();
  lastName = lastName.trim();

  if(firstName.length < 2) throw "short string";
  if(lastName.length < 2) throw "short string";

  if(firstName.length > 25) throw "long string";
  if(lastName.length > 25) throw "long string";

  if(typeof userId !== 'string') throw "improper paramater type";
  if((/\d/.test(userId))) throw "number in userId";
  userId = userId.trim().toLowerCase();
  if(userId.length < 5) throw "short string";
  if(userId.length > 10) throw "long string";

  if(typeof password !== 'string') throw "improper paramater type";
  password = password.trim();
  if(password.includes(" ")) throw "space in password";
  if(password.length < 8) throw "short password";
  if(!(/\d/.test(password))) throw "include number in password";
  if(!(/[A-Z]/.test(password))) throw "include uppercase in password";
  if(!(/[^a-zA-Z0-9]/.test(password))) throw "include special character in password";

  if(typeof favoriteQuote !== 'string') throw "improper parameter";
  favoriteQuote = favoriteQuote.trim();
  if(favoriteQuote.length < 20) throw "short string";
  if(favoriteQuote.length > 255) throw "long string";

  if(typeof themePreference !== "object") throw "invalid parameter";
  if(Array.isArray(themePreference)) throw "invalid parameter";
  if(Object.entries(themePreference).length > 2 || Object.entries(themePreference).length < 2) throw "more/less than 2 preferences";
  if(!('backgroundColor' in themePreference)) throw "include backgroundColor in themePreference";
  if(!('fontColor' in themePreference)) throw "include fontColor in themePreference";
  if(!(/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$/.test(themePreference.backgroundColor))) throw "invalid hex";
  if(!(/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$/.test(themePreference.fontColor))) throw "invalid hex";
  if(themePreference.backgroundColor === themePreference.fontColor) throw "same color";

  if(typeof role !== 'string') throw "invalid parameter";
  role = role.trim().toLowerCase();
  if(role !== "admin" && role !== "user") throw "role must be admin or user";

  const hash = await bcrypt.hash(password, saltRounds);

  const usersCollection = await users();

  const found = await usersCollection.findOne({userId: userId});

  if(found) throw "userId already exists";


  const user = {
    firstName: firstName,
    lastName: lastName,
    userId: userId,
    password: hash,
    favoriteQuote: favoriteQuote,
    themePreference: themePreference,
    role: role
  }

  const inserting = await usersCollection.insertOne(user);

  if(!inserting.acknowledged || !inserting.insertedId) throw "could not add user";

  const ans = {
    registrationCompleted: true
  }

  return ans;
}

export const signInUser = async (userId, password) => {

  if(!userId || !password) throw "invalid params";

  if(typeof userId !== 'string') throw "improper paramater type";
  if((/\d/.test(userId))) throw "number in userId";
  userId = userId.trim().toLowerCase();
  if(userId.length < 5) throw "short string";
  if(userId.length > 10) throw "long string";

  if(typeof password !== 'string') throw "improper paramater type";
  password = password.trim();
  if(password.includes(" ")) throw "space in password";
  if(password.length < 8) throw "short password";
  if(!(/\d/.test(password))) throw "include number in password";
  if(!(/[A-Z]/.test(password))) throw "include uppercase in password";
  if(!(/[^a-zA-Z0-9]/.test(password))) throw "include special character in password";

  const usersCollection = await users();

  const found = await usersCollection.findOne({userId: userId});

  if(!found) throw "Either the userId or password is invalid";

  const match = await bcrypt.compare(password, found.password);

  if(!match) throw "Either the userId or password is invalid";

  const ans = {
    firstName: found.firstName,
    lastName: found.lastName,
    userId: found.userId,
    favoriteQuote: found.favoriteQuote,
    themePreference: found.themePreference,
    role: found.role
  }

  return ans;
};


