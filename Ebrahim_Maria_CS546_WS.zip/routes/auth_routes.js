//import express, express router as shown in lecture code

import {Router} from 'express';
const router = Router();

import {signInUser, signUpUser} from '../data/users.js';

router.route('/').get(async (req, res) => {
  //code here for GET THIS ROUTE SHOULD NEVER FIRE BECAUSE OF MIDDLEWARE #1 IN SPECS.
  return res.json({error: 'YOU SHOULD NOT BE HERE!'});
});

router
  .route('/signupuser')
  .get(async (req, res) => {
    //code here for GET
      res.render('signupuser', {Title: 'Sign Up'});
  })
  .post(async (req, res) => {
    //code here for POST
    let {
      firstName,
      lastName,
      userId,
      password,
      confirmPassword,
      favoriteQuote,
      backgroundColor,
      fontColor,
      role
    } = req.body;

    let dbCheck = "";

    let themePreference = {
      backgroundColor: backgroundColor,
      fontColor: fontColor
    }

    try{

    let missingItems = "";
    
    if(!firstName){
        missingItems += "First Name\n";
    }

    if(!lastName){
        missingItems += "Last Name\n";
    }

    if(!userId){
        missingItems += "userId\n";
    }

    if(!password){
        missingItems += "Password\n";
    }

    if(!confirmPassword){
        missingItems += "Confirm Password\n";
    }

    if(!favoriteQuote){
        missingItems += "Favorite Quote\n";
    }

    if(!backgroundColor){
        missingItems += "Background Color\n";
    }

    if(!fontColor){
        missingItems += "Font Color\n";
    }

    if(!role){
        missingItems += "Role\n";
    }

    if(missingItems.length > 1){
        let err = "The following feilds are missing:\n" + missingItems;
        throw err 
    }
    

    if(typeof firstName !== 'string') throw "improper paramater type for first name okkk";
    if(typeof lastName !== 'string') throw "improper paramater typefor last name";
  
    if((/\d/.test(firstName))) throw "number in first name";
    if((/\d/.test(lastName))) throw "number in last name";
  
    firstName = firstName.trim();
    lastName = lastName.trim();
  
    if(firstName.length < 2) throw "short string for first name";
    if(lastName.length < 2) throw "short string for last name";
  
    if(firstName.length > 25) throw "long string";
    if(lastName.length > 25) throw "long string";
  
    if(typeof userId !== 'string') throw "improper paramater type";
    if((/\d/.test(userId))) throw "number in userId";
    userId = userId.trim().toLowerCase();
    if(userId.length < 5) throw "short string";
    if(userId.length > 10) throw "long string";
  
    if(typeof password !== 'string') throw "improper paramater type";
    password = password.trim();
    if(password.includes(" ")) throw "space in password";
    if(password.length < 8) throw "short password";
    if(!(/\d/.test(password))) throw "include number in password";
    if(!(/[A-Z]/.test(password))) throw "include uppercase in password";
    if(!(/[^a-zA-Z0-9]/.test(password))) throw "include special character in password";

    if(confirmPassword !== password) throw "passwords do not match";
  
    if(typeof favoriteQuote !== 'string') throw "improper parameter";
    favoriteQuote = favoriteQuote.trim();
    if(favoriteQuote.length < 20) throw "short string";
    if(favoriteQuote.length > 255) throw "long string";

    if(!(/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$/.test(backgroundColor))) throw "invalid hex";
    if(!(/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$/.test(fontColor))) throw "invalid hex";
    if(backgroundColor === fontColor) throw "same color";

    if(typeof role !== 'string') throw "invalid parameter";
    role = role.trim().toLowerCase();
    if(role !== "admin" && role !== "user") throw "role must be admin or user";

    dbCheck = await signUpUser(firstName,
      lastName,
      userId,
      password,
      favoriteQuote,
      themePreference,
      role);

      if(JSON.stringify(dbCheck) === JSON.stringify({registrationCompleted: true})){
        res.redirect('/signinuser');
      }else{
          //DO I RERENDER THE SIGNUP PAGE???
          res.status(500).render('signupuser', {Title: 'Sign Up', Error: 'Internal Server Error'});
      }

    }catch(e){
      res.status(400).render('signupuser', {Title: 'Sign Up', Error: e});
    }


    // if(JSON.stringify(dbCheck) === JSON.stringify({registrationCompleted: true})){
    //   res.redirect('/signinuser');
    // }else{
    //     //DO I RERENDER THE SIGNUP PAGE???
    //     res.status(500).render('signupuser', {Title: 'Sign Up', Error: 'Internal Server Error'});
    // }


  });

router
  .route('/signinuser')
  .get(async (req, res) => {
    //code here for GET
      res.render('signinuser', {Title: 'Sign In'});
  })
  .post(async (req, res) => {
    //code here for POST
    let {
      user_id,
      password
    } = req.body;
    let userId = user_id;
    let dbCheck = {};
    try{
    if(!userId || !password) throw "missing params herree";

            if(typeof userId !== 'string') throw "improper paramater type";
            if((/\d/.test(userId))) throw "number in userId";
            userId = userId.trim().toLowerCase();
            if(userId.length < 5) throw "short string";
            if(userId.length > 10) throw "long string";

            if(typeof password !== 'string') throw "improper paramater type";
            password = password.trim();
            if(password.includes(" ")) throw "space in password";
            if(password.length < 8) throw "short password";
            if(!(/\d/.test(password))) throw "include number in password";
            if(!(/[A-Z]/.test(password))) throw "include uppercase in password";
            if(!(/[^a-zA-Z0-9]/.test(password))) throw "include special character in password";

            dbCheck = await signInUser(userId, password);
          }
    catch(e){
      //THIS SHOULD TRIGGER ERROR HANDELBAR
       res.status(400).render('signinuser', {Title: 'Sign In', Error: e});
    }



    req.session.user = {
      firstName: dbCheck.firstName,
      lastName: dbCheck.lastName,
      userId: dbCheck.userId,
      favoriteQuote: dbCheck.favoriteQuote,
      themePreference: dbCheck.themePreference,
      role: dbCheck.role
    }

    if(dbCheck.role === "admin"){
      res.redirect('/administrator');
    }
    if(dbCheck.role === "user"){
      res.redirect('/user');
    }
  });

router.route('/user').get(async (req, res) => {
  //code here for GET
    let currTime = new Date();
    let currentDate = currTime.toLocaleDateString();
    let currentTime = currTime.toLocaleTimeString();
    res.render('user', {Title: 'User', firstName: req.session.user.firstName, lastName: req.session.user.lastName, currentTime: currentTime, currentDate: currentDate, role: req.session.user.role, favoriteQuote: req.session.user.favoriteQuote, themePreference: req.session.user.themePreference});
});

router.route('/administrator').get(async (req, res) => {
  //code here for GET
  let currTime = new Date();
    let currentDate = currTime.toLocaleDateString();
    let currentTime = currTime.toLocaleTimeString();
  res.render('administrator', {Title: 'Administrator', firstName: req.session.user.firstName, lastName: req.session.user.lastName, currentTime: currentTime, currentDate: currentDate, favoriteQuote: req.session.user.favoriteQuote, themePreference: req.session.user.themePreference});
});

router.route('/signoutuser').get(async (req, res) => {
  //code here for GET
  req.session.destroy();
  res.render('signoutuser', {Title: 'Sign Out'});
});

export default router;